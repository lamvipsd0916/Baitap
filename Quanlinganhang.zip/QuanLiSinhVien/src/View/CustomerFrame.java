package View;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Data.Customer;
import Data.CustomerModify;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class CustomerFrame extends javax.swing.JFrame {

    DefaultTableModel tableModel;
    List<Customer> dataList;
    int currentPos = -1;

    
    public CustomerFrame() {
        initComponents();

        tableModel = (DefaultTableModel) customerTable.getModel();
        dataList = CustomerModify.getCustomerList(null);

        showData();

        customerTable.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                currentPos = customerTable.getSelectedRow();

                fullnameTxt.setText(dataList.get(currentPos).getFullname());
                emailTxt.setText(dataList.get(currentPos).getEmail());
                phoneTxt.setText(dataList.get(currentPos).getPhoneNumber());
                accountnumberTxt.setText(dataList.get(currentPos).getAccountnumber());
                sexTxt.setText(dataList.get(currentPos).getSex());
                pwdTxt.setText(dataList.get(currentPos).getCCCDnumber());
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }
        });
    }

    private void showData() {
        tableModel.setRowCount(0);
        for (Customer customer : dataList) {
            tableModel.addRow(new Object[]{
                tableModel.getRowCount() + 1,
                customer.getFullname(),
                customer.getEmail(),
                customer.getPhoneNumber(),
                customer.getAccountnumber(),
                customer.getSex(),
                customer.getCCCDnumber()
            });
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        fullnameTxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        emailTxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        phoneTxt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        accountnumberTxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
       sexTxt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        pwdTxt = new javax.swing.JTextField();
        saveBtn = new javax.swing.JButton();
        delBtn = new javax.swing.JButton();
        searchBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        customerTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle(" QUẢN LÝ THÔNG TIN KHÁCH HÀNG");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("NHẬP THÔNG TIN KHÁCH HÀNG"));

        jLabel1.setText("Tên KH:");

        jLabel2.setText("Email:");

        jLabel3.setText("Số Điện Thoại:");

        jLabel4.setText("Số Tài Khoản:");

        jLabel5.setText("Giới Tính:");

        jLabel6.setText("Số CCCD:");

        saveBtn.setText("Lưu");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        delBtn.setText("Xoá");
        delBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delBtnActionPerformed(evt);
            }
        });

        searchBtn.setText("Tìm Kiếm");
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });
        
        JButton btnNewButton = new JButton("Chỉnh sửa");
        btnNewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBtnActionPerformed(evt);
            }
        });
        
        JButton btntailai = new JButton("Tải lại");
        btntailai.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		dataList = CustomerModify.getCustomerList(null);
        		showData();
        	}
        });
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGap(14)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING, false)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel6)
        					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        					.addComponent(pwdTxt, GroupLayout.PREFERRED_SIZE, 337, GroupLayout.PREFERRED_SIZE))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel5)
        					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        					.addComponent(sexTxt, GroupLayout.PREFERRED_SIZE, 337, GroupLayout.PREFERRED_SIZE))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel4)
        					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        					.addComponent(accountnumberTxt, GroupLayout.PREFERRED_SIZE, 337, GroupLayout.PREFERRED_SIZE))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel3)
        					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        					.addComponent(phoneTxt, GroupLayout.PREFERRED_SIZE, 337, GroupLayout.PREFERRED_SIZE))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel2)
        					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        					.addComponent(emailTxt, GroupLayout.PREFERRED_SIZE, 337, GroupLayout.PREFERRED_SIZE))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel1)
        					.addGap(74)
        					.addComponent(fullnameTxt, GroupLayout.PREFERRED_SIZE, 337, GroupLayout.PREFERRED_SIZE)))
        			.addGap(32)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING, false)
        				.addComponent(btntailai, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        				.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        				.addComponent(saveBtn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        				.addComponent(delBtn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        				.addComponent(searchBtn, GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE))
        			.addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel1)
        				.addComponent(fullnameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(saveBtn))
        			.addGap(18)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel2)
        				.addComponent(emailTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(delBtn))
        			.addGap(18)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel3)
        				.addComponent(phoneTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(searchBtn))
        			.addGap(18)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel4)
        				.addComponent(accountnumberTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton))
        			.addGap(18)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel5)
        				.addComponent(sexTxt, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btntailai))
        			.addGap(21)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel6)
        				.addComponent(pwdTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1.setLayout(jPanel1Layout);

        customerTable.setModel(new DefaultTableModel(
        	new Object[][] {
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        	},
        	new String[] {
        		"STT", "H\u1ECD T\u00EAn", "Email", "S\u0110T", "S\u1ED1 t\u00E0i Kho\u1EA3n", "Gi\u1EDBi T\u00EDnh", "S\u1ED1 CCCD"
        	}
        ));
        jScrollPane1.setViewportView(customerTable);
        if (customerTable.getColumnModel().getColumnCount() > 0) {
            customerTable.getColumnModel().getColumn(0).setResizable(false);
            customerTable.getColumnModel().getColumn(1).setResizable(false);
            customerTable.getColumnModel().getColumn(2).setResizable(false);
            customerTable.getColumnModel().getColumn(3).setResizable(false);
            customerTable.getColumnModel().getColumn(4).setResizable(false);
            customerTable.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 628, Short.MAX_VALUE)
        				.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        			.addContainerGap())
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 163, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        getContentPane().setLayout(layout);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        // TODO add your handling code here:
        if (currentPos >= 0) {
            dataList.get(currentPos).setFullname(fullnameTxt.getText());
            dataList.get(currentPos).setEmail(emailTxt.getText());
            dataList.get(currentPos).setPhoneNumber(phoneTxt.getText());
            dataList.get(currentPos).setAccountnumber(accountnumberTxt.getText());
            dataList.get(currentPos).setSex(sexTxt.getText());
            dataList.get(currentPos).setCCCDnumber(pwdTxt.getText());
            
            CustomerModify.update(dataList.get(currentPos));
            currentPos = -1;
        } else {
            Customer customer = new Customer(
                    0,
                    fullnameTxt.getText(),
                    emailTxt.getText(),
                    phoneTxt.getText(),
                    accountnumberTxt.getText(),
                    sexTxt.getText(),
                    pwdTxt.getText()
            );
            CustomerModify.insert(customer);
            dataList = CustomerModify.getCustomerList(null);
        }
        showData();

        fullnameTxt.setText("");
        emailTxt.setText("");
        phoneTxt.setText("");
        accountnumberTxt.setText("");
        sexTxt.setText("");
        pwdTxt.setText("");
    }//GEN-LAST:event_saveBtnActionPerformed

    private void delBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delBtnActionPerformed
        // TODO add your handling code here:
        if(currentPos == -1) {
            JOptionPane.showMessageDialog(rootPane, "Chưa chọn khách hàng cần xóa, cần kiểm tra lại!");
            return;
        }
        int option = JOptionPane.showConfirmDialog(rootPane, "Bạn chắc chắn muốn xóa khách hàng này không?");
        if(option == 0) {
            CustomerModify.delete(dataList.get(currentPos).getId());
            dataList.remove(currentPos);
            currentPos = -1;
            showData();
        }

        fullnameTxt.setText("");
        emailTxt.setText("");
        phoneTxt.setText("");
        accountnumberTxt.setText("");
        sexTxt.setText("");
        pwdTxt.setText("");
    }//GEN-LAST:event_delBtnActionPerformed

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        // TODO add your handling code here:
        String s = JOptionPane.showInputDialog("Nhập tên khách hàng cần tìm kiếm");
        if(!s.isEmpty()) {
            s = "%"+s+"%";
        }
        dataList = CustomerModify.getCustomerList(s);
        showData();
    }//GEN-LAST:event_searchBtnActionPerformed
    private void editBtnActionPerformed(java.awt.event.ActionEvent evt) {
        if (currentPos >= 0) {
            dataList.get(currentPos).setFullname(fullnameTxt.getText());
            dataList.get(currentPos).setEmail(emailTxt.getText());
            dataList.get(currentPos).setPhoneNumber(phoneTxt.getText());
            dataList.get(currentPos).setAccountnumber(accountnumberTxt.getText());
            dataList.get(currentPos).setSex(sexTxt.getText());
            dataList.get(currentPos).setCCCDnumber(pwdTxt.getText());
            
            CustomerModify.update(dataList.get(currentPos));
            currentPos = -1;
            showData();
            
            // Xóa dữ liệu khỏi các trường nhập
            clearFields();
        } else {
            // Hiển thị thông báo hoặc xử lý khi không có khách hàng nào được chọn
        }
    }
    private void clearFields() {
        fullnameTxt.setText("");
        emailTxt.setText("");
        phoneTxt.setText("");
        accountnumberTxt.setText("");
        sexTxt.setText("");
        pwdTxt.setText("");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField sexTxt;
    private javax.swing.JTextField accountnumberTxt;
    private javax.swing.JTable customerTable;
    private javax.swing.JButton delBtn;
    private javax.swing.JTextField emailTxt;
    private javax.swing.JTextField fullnameTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField phoneTxt;
    private javax.swing.JTextField pwdTxt;
    private javax.swing.JButton saveBtn;
    private javax.swing.JButton searchBtn;
}