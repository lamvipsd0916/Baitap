/**
 * 
 */
/**
 * 
 */
module QuanLiSinhVien {
	requires java.desktop;
	requires java.sql;
}