package Data;

public interface Config {
	String url = "jdbc:mySQL://localhost:3306/btnganhang";
	String username = "root";
	String password = "Kakakaka1234@";
}
