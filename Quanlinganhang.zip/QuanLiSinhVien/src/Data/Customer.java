package Data;

public class Customer {
    int id;
    String fullname, email, phoneNumber, accountnumber, sex, CCCDnumber;

    public Customer() {
    }

    public Customer(int id, String fullname, String email, String phoneNumber, String accountnumber , String sex, String CCCDnumber) {
        this.id = id;
        this.fullname = fullname;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.accountnumber= accountnumber;
        this.sex=sex;
        this.CCCDnumber=CCCDnumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    
    public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getCCCDnumber() {
		return CCCDnumber;
	}

	public void setCCCDnumber(String CCCDnumber) {
		this.CCCDnumber=CCCDnumber;
	}

	@Override
    public String toString() {
        return "Customer{" + "id=" + id + ", fullname=" + fullname + ", email=" + email + ", phoneNumber=" + phoneNumber + ", accountNumber=" + accountnumber + ", sex=" + sex + ", CCCDNumber=" + CCCDnumber + '}';
    }
}
